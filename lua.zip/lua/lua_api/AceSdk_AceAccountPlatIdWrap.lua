---@class AceSdk.AceAccountPlatId : System.Enum
---@field value__ int
---@field ACEPLAT_ID_IOS AceSdk.AceAccountPlatId
---@field ACEPLAT_ID_ANDROID AceSdk.AceAccountPlatId
---@field ACEPLAT_ID_RESERVE AceSdk.AceAccountPlatId
---@field ACEPLAT_ID_PC_CLIENT AceSdk.AceAccountPlatId
---@field ACEPLAT_ID_MICRO_WEB AceSdk.AceAccountPlatId
---@field ACEPLAT_ID_MICRO_CLIENT AceSdk.AceAccountPlatId
---@field ACEPLAT_ID_SWITCH AceSdk.AceAccountPlatId
local m = {}
AceSdk = {}
AceSdk.AceAccountPlatId = m
return m