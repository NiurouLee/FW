---@class H3DGCloudLuaHelper.FunnelStepEvents : System.Enum
---@field value__ int
---@field Login H3DGCloudLuaHelper.FunnelStepEvents
---@field Pay H3DGCloudLuaHelper.FunnelStepEvents
---@field Test1 H3DGCloudLuaHelper.FunnelStepEvents
local m = {}
H3DGCloudLuaHelper = {}
H3DGCloudLuaHelper.FunnelStepEvents = m
return m