---@class ChannelConfigInfo : object
---@field Apple_WX bool
---@field Apple_QQ bool
---@field Apple_Guest bool
---@field Apple_Facebook bool
---@field Apple_Apple bool
---@field Apple_Line bool
---@field Apple_Twitter bool
---@field Apple_CustomAccount bool
---@field Apple_DMM bool
---@field Other_WX bool
---@field Other_QQ bool
---@field Other_Guest bool
---@field Other_Facebook bool
---@field Other_Google bool
---@field Other_Line bool
---@field Other_Twitter bool
---@field Other_CustomAccount bool
---@field Other_DMM bool
local m = {}
ChannelConfigInfo = m
return m