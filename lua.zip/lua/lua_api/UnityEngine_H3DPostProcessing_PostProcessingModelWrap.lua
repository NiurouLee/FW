---@class UnityEngine.H3DPostProcessing.PostProcessingModel : object
---@field enabled bool
local m = {}
function m:Reset() end
function m:OnValidate() end
UnityEngine = {}
UnityEngine.H3DPostProcessing = {}
UnityEngine.H3DPostProcessing.PostProcessingModel = m
return m