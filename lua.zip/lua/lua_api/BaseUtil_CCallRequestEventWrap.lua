---@class BaseUtil.CCallRequestEvent : BaseUtil.CCallEvent
---@field flag int
local m = {}
BaseUtil = {}
BaseUtil.CCallRequestEvent = m
return m