---@class BoundView : UnityEngine.MonoBehaviour
---@field LeftOffest float
---@field UpOffset float
---@field RightOffset float
---@field DownOffset float
local m = {}
---@param go UnityEngine.GameObject
---@return BoundView
function m.Get(go) end
BoundView = m
return m