---@class LoadAlphaPost : UnityEngine.MonoBehaviour
---@field postMask UnityEngine.UI.Image
---@field offset UnityEngine.Vector2
local m = {}
function m:SetData() end
LoadAlphaPost = m
return m