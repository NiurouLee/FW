---@class UnityEngine.AudioBehaviour : UnityEngine.Behaviour
local m = {}
UnityEngine = {}
UnityEngine.AudioBehaviour = m
return m