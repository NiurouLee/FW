---@class UnityEngine.TextureWrapMode : System.Enum
---@field value__ int
---@field Repeat UnityEngine.TextureWrapMode
---@field Clamp UnityEngine.TextureWrapMode
---@field Mirror UnityEngine.TextureWrapMode
---@field MirrorOnce UnityEngine.TextureWrapMode
local m = {}
UnityEngine = {}
UnityEngine.TextureWrapMode = m
return m