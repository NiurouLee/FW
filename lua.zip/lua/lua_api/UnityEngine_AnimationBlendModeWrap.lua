---@class UnityEngine.AnimationBlendMode : System.Enum
---@field value__ int
---@field Blend UnityEngine.AnimationBlendMode
---@field Additive UnityEngine.AnimationBlendMode
local m = {}
UnityEngine = {}
UnityEngine.AnimationBlendMode = m
return m