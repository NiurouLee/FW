---@class UnityEngine.RenderTextureReadWrite : System.Enum
---@field value__ int
---@field Default UnityEngine.RenderTextureReadWrite
---@field Linear UnityEngine.RenderTextureReadWrite
---@field sRGB UnityEngine.RenderTextureReadWrite
local m = {}
UnityEngine = {}
UnityEngine.RenderTextureReadWrite = m
return m