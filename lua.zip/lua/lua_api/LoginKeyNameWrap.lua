---@class LoginKeyName : object
---@field FirstLogin string
---@field LoginPrivacy string
---@field LoginUser string
---@field LoginPUTime string
---@field ChannelId string
---@field StateRegion string
---@field EuAgree string
---@field ZoneId string
---@field Korea string
---@field OpenIdTest string
---@field FirstLaunchApp string
---@field LastEnterGameUserId string
local m = {}
LoginKeyName = m
return m