---@class ActorViewType : System.Enum
---@field value__ int
---@field Normal ActorViewType
---@field Ghost ActorViewType
---@field DotSelected ActorViewType
local m = {}
ActorViewType = m
return m