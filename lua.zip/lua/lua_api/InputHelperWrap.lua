---@class InputHelper : object
local m = {}
---@return table
function m.LastFramePositionArray() end
---@return bool
function m.IsPointerOverGameObject() end
InputHelper = m
return m