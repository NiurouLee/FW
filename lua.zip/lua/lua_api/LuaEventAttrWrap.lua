---@class LuaEventAttr : object
---@field Clsid int
---@field Type LuaEventType
---@field Encrypt bool
---@field Reliable bool
---@field Name string
local m = {}
LuaEventAttr = m
return m