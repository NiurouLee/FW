---@class UnityEngine.PrimitiveType : System.Enum
---@field value__ int
---@field Sphere UnityEngine.PrimitiveType
---@field Capsule UnityEngine.PrimitiveType
---@field Cylinder UnityEngine.PrimitiveType
---@field Cube UnityEngine.PrimitiveType
---@field Plane UnityEngine.PrimitiveType
---@field Quad UnityEngine.PrimitiveType
local m = {}
UnityEngine = {}
UnityEngine.PrimitiveType = m
return m