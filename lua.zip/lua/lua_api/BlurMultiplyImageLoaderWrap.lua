---@class BlurMultiplyImageLoader : UnityEngine.MonoBehaviour
---@field targetImage UnityEngine.UI.RawImage
---@field shadowImage UnityEngine.UI.RawImage
---@field shadowOffset UnityEngine.Vector2
local m = {}
---@param _name string
function m:Load(_name) end
BlurMultiplyImageLoader = m
return m