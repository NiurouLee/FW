---@class Cinemachine.CinemachineBrain.VcamActivatedEvent : UnityEngine.Events.UnityEvent
local m = {}
Cinemachine = {}
Cinemachine.CinemachineBrain = {}
Cinemachine.CinemachineBrain.VcamActivatedEvent = m
return m