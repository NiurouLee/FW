---@class SmeltDropdown : UnityEngine.UI.Dropdown
---@field onShow System.Action
---@field onHide System.Action
local m = {}
SmeltDropdown = m
return m