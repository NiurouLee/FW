---@class MSDKStatus : System.Enum
---@field value__ int
---@field MS_None MSDKStatus
---@field MS_Inland MSDKStatus
---@field MS_International MSDKStatus
local m = {}
MSDKStatus = m
return m