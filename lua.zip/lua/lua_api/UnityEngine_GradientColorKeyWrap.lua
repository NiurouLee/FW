---@class UnityEngine.GradientColorKey
---@field color UnityEngine.Color
---@field time float
local m = {}
UnityEngine = {}
UnityEngine.GradientColorKey = m
return m