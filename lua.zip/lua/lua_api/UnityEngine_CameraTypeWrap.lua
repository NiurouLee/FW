---@class UnityEngine.CameraType : System.Enum
---@field value__ int
---@field Game UnityEngine.CameraType
---@field SceneView UnityEngine.CameraType
---@field Preview UnityEngine.CameraType
---@field VR UnityEngine.CameraType
---@field Reflection UnityEngine.CameraType
local m = {}
UnityEngine = {}
UnityEngine.CameraType = m
return m