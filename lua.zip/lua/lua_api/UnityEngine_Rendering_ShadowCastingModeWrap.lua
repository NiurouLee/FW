---@class UnityEngine.Rendering.ShadowCastingMode : System.Enum
---@field value__ int
---@field Off UnityEngine.Rendering.ShadowCastingMode
---@field On UnityEngine.Rendering.ShadowCastingMode
---@field TwoSided UnityEngine.Rendering.ShadowCastingMode
---@field ShadowsOnly UnityEngine.Rendering.ShadowCastingMode
local m = {}
UnityEngine = {}
UnityEngine.Rendering = {}
UnityEngine.Rendering.ShadowCastingMode = m
return m