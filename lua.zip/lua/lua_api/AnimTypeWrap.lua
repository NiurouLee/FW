---@class AnimType : System.Enum
---@field value__ int
---@field Begin AnimType
---@field Middle AnimType
---@field End AnimType
local m = {}
AnimType = m
return m