---@class EmptyImage : UnityEngine.UI.Graphic
local m = {}
EmptyImage = m
return m