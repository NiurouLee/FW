---@class BulletinInfo : object
---@field id int
---@field name string
---@field host string
---@field port ushort
local m = {}
BulletinInfo = m
return m