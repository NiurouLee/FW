---@class OutlineComponent.BlendType : System.Enum
---@field value__ int
---@field Add OutlineComponent.BlendType
---@field Blend OutlineComponent.BlendType
local m = {}
OutlineComponent = {}
OutlineComponent.BlendType = m
return m