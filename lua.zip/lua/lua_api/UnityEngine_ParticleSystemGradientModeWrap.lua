---@class UnityEngine.ParticleSystemGradientMode : System.Enum
---@field value__ int
---@field Color UnityEngine.ParticleSystemGradientMode
---@field Gradient UnityEngine.ParticleSystemGradientMode
---@field TwoColors UnityEngine.ParticleSystemGradientMode
---@field TwoGradients UnityEngine.ParticleSystemGradientMode
---@field RandomColor UnityEngine.ParticleSystemGradientMode
local m = {}
UnityEngine = {}
UnityEngine.ParticleSystemGradientMode = m
return m