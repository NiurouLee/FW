---@class UnityEngine.H3DPostProcessing.AntialiasingModel.Settings
---@field defaultSettings UnityEngine.H3DPostProcessing.AntialiasingModel.Settings
---@field method UnityEngine.H3DPostProcessing.AntialiasingModel.Method
---@field fxaaSettings UnityEngine.H3DPostProcessing.AntialiasingModel.FxaaSettings
---@field taaSettings UnityEngine.H3DPostProcessing.AntialiasingModel.TaaSettings
local m = {}
UnityEngine = {}
UnityEngine.H3DPostProcessing = {}
UnityEngine.H3DPostProcessing.AntialiasingModel = {}
UnityEngine.H3DPostProcessing.AntialiasingModel.Settings = m
return m