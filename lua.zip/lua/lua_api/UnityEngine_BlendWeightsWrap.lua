---@class UnityEngine.BlendWeights : System.Enum
---@field value__ int
---@field OneBone UnityEngine.BlendWeights
---@field TwoBones UnityEngine.BlendWeights
---@field FourBones UnityEngine.BlendWeights
local m = {}
UnityEngine = {}
UnityEngine.BlendWeights = m
return m