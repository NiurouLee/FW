---@class UIInputFieldValidatorTMP : TMPro.TMP_InputValidator
local m = {}
---@param text string
---@param pos int
---@param ch char
---@return char
function m:Validate(text, pos, ch) end
UIInputFieldValidatorTMP = m
return m