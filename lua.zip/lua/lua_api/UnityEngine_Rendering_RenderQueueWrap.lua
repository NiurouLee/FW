---@class UnityEngine.Rendering.RenderQueue : System.Enum
---@field value__ int
---@field Background UnityEngine.Rendering.RenderQueue
---@field Geometry UnityEngine.Rendering.RenderQueue
---@field AlphaTest UnityEngine.Rendering.RenderQueue
---@field GeometryLast UnityEngine.Rendering.RenderQueue
---@field Transparent UnityEngine.Rendering.RenderQueue
---@field Overlay UnityEngine.Rendering.RenderQueue
local m = {}
UnityEngine = {}
UnityEngine.Rendering = {}
UnityEngine.Rendering.RenderQueue = m
return m