---@class EGameStartType : System.Enum
---@field value__ int
---@field Normal EGameStartType
---@field UITest EGameStartType
---@field ResourceTest EGameStartType
---@field StoryViewer EGameStartType
---@field SkillEditor EGameStartType
---@field BattleSmokingTest EGameStartType
---@field StoryViewer3D EGameStartType
local m = {}
EGameStartType = m
return m