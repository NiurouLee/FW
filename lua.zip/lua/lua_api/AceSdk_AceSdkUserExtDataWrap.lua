---@class AceSdk.AceSdkUserExtData
---@field user_ext_data_ string
---@field ext_data_len_ uint
local m = {}
AceSdk = {}
AceSdk.AceSdkUserExtData = m
return m