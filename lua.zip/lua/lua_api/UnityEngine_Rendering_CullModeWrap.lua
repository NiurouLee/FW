---@class UnityEngine.Rendering.CullMode : System.Enum
---@field value__ int
---@field Off UnityEngine.Rendering.CullMode
---@field Front UnityEngine.Rendering.CullMode
---@field Back UnityEngine.Rendering.CullMode
local m = {}
UnityEngine = {}
UnityEngine.Rendering = {}
UnityEngine.Rendering.CullMode = m
return m