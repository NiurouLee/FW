---@class UnityEngine.EventType : System.Enum
---@field value__ int
---@field MouseDown UnityEngine.EventType
---@field MouseUp UnityEngine.EventType
---@field MouseMove UnityEngine.EventType
---@field MouseDrag UnityEngine.EventType
---@field KeyDown UnityEngine.EventType
---@field KeyUp UnityEngine.EventType
---@field ScrollWheel UnityEngine.EventType
---@field Repaint UnityEngine.EventType
---@field Layout UnityEngine.EventType
---@field DragUpdated UnityEngine.EventType
---@field DragPerform UnityEngine.EventType
---@field DragExited UnityEngine.EventType
---@field Ignore UnityEngine.EventType
---@field Used UnityEngine.EventType
---@field ValidateCommand UnityEngine.EventType
---@field ExecuteCommand UnityEngine.EventType
---@field ContextClick UnityEngine.EventType
---@field MouseEnterWindow UnityEngine.EventType
---@field MouseLeaveWindow UnityEngine.EventType
local m = {}
UnityEngine = {}
UnityEngine.EventType = m
return m