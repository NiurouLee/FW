---@class UnityEngine.UI.RawImage : UnityEngine.UI.MaskableGraphic
---@field mainTexture UnityEngine.Texture
---@field texture UnityEngine.Texture
---@field uvRect UnityEngine.Rect
local m = {}
function m:SetNativeSize() end
UnityEngine = {}
UnityEngine.UI = {}
UnityEngine.UI.RawImage = m
return m