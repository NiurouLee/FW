---@class HotUpdate.ActivityDownloaderCallbackType : System.Enum
---@field value__ int
---@field DownloadError HotUpdate.ActivityDownloaderCallbackType
---@field FatalError HotUpdate.ActivityDownloaderCallbackType
---@field Finish HotUpdate.ActivityDownloaderCallbackType
---@field SpaceNotEnough HotUpdate.ActivityDownloaderCallbackType
---@field NotUseWifi HotUpdate.ActivityDownloaderCallbackType
local m = {}
HotUpdate = {}
HotUpdate.ActivityDownloaderCallbackType = m
return m