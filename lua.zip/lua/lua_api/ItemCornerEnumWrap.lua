---@class ItemCornerEnum : System.Enum
---@field value__ int
---@field LeftBottom ItemCornerEnum
---@field LeftTop ItemCornerEnum
---@field RightTop ItemCornerEnum
---@field RightBottom ItemCornerEnum
local m = {}
ItemCornerEnum = m
return m