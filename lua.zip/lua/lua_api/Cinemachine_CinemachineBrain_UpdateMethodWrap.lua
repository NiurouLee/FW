---@class Cinemachine.CinemachineBrain.UpdateMethod : System.Enum
---@field value__ int
---@field FixedUpdate Cinemachine.CinemachineBrain.UpdateMethod
---@field LateUpdate Cinemachine.CinemachineBrain.UpdateMethod
---@field SmartUpdate Cinemachine.CinemachineBrain.UpdateMethod
---@field ManualUpdate Cinemachine.CinemachineBrain.UpdateMethod
local m = {}
Cinemachine = {}
Cinemachine.CinemachineBrain = {}
Cinemachine.CinemachineBrain.UpdateMethod = m
return m