---@class LodLevel : System.Enum
---@field value__ int
---@field low LodLevel
---@field normal LodLevel
---@field high LodLevel
local m = {}
LodLevel = m
return m