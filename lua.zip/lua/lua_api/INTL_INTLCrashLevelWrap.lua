---@class INTL.INTLCrashLevel : System.Enum
---@field value__ int
---@field LogLevelSilent INTL.INTLCrashLevel
---@field LogLevelError INTL.INTLCrashLevel
---@field LogLevelWarn INTL.INTLCrashLevel
---@field LogLevelInfo INTL.INTLCrashLevel
---@field LogLevelDebug INTL.INTLCrashLevel
---@field LogLevelVerbose INTL.INTLCrashLevel
local m = {}
INTL = {}
INTL.INTLCrashLevel = m
return m