---@class TMPro.TMP_InputField.OnChangeEvent : UnityEngine.Events.UnityEvent
local m = {}
TMPro = {}
TMPro.TMP_InputField = {}
TMPro.TMP_InputField.OnChangeEvent = m
return m