---@class INTL.INTLPushResult : INTL.INTLBaseResult
---@field Type int
---@field Notification string
local m = {}
INTL = {}
INTL.INTLPushResult = m
return m