---@class ShadowmapCheckPoint : UnityEngine.MonoBehaviour
---@field targetMtl table
---@field targetTrans table
local m = {}
function m:SetMtls() end
ShadowmapCheckPoint = m
return m