---@class UnityEngine.ParticleSystemCustomData : System.Enum
---@field value__ int
---@field Custom1 UnityEngine.ParticleSystemCustomData
---@field Custom2 UnityEngine.ParticleSystemCustomData
local m = {}
UnityEngine = {}
UnityEngine.ParticleSystemCustomData = m
return m