---@class UnityEngine.AI.NavMeshPathStatus : System.Enum
---@field value__ int
---@field PathComplete UnityEngine.AI.NavMeshPathStatus
---@field PathPartial UnityEngine.AI.NavMeshPathStatus
---@field PathInvalid UnityEngine.AI.NavMeshPathStatus
local m = {}
UnityEngine = {}
UnityEngine.AI = {}
UnityEngine.AI.NavMeshPathStatus = m
return m