---@class GCloud.AnoSDK.AnoSDKIoctlCMD : System.Enum
---@field value__ int
---@field IsEmulator GCloud.AnoSDK.AnoSDKIoctlCMD
---@field CommQuery GCloud.AnoSDK.AnoSDKIoctlCMD
---@field InitSwitchStr GCloud.AnoSDK.AnoSDKIoctlCMD
local m = {}
GCloud = {}
GCloud.AnoSDK = {}
GCloud.AnoSDK.AnoSDKIoctlCMD = m
return m