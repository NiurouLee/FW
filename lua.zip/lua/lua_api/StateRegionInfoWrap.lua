---@class StateRegionInfo : object
---@field Numeric string
---@field Name string
---@field EEA bool
local m = {}
StateRegionInfo = m
return m