---@class UnityEngine.Rendering.BuiltinRenderTextureType : System.Enum
---@field value__ int
---@field PropertyName UnityEngine.Rendering.BuiltinRenderTextureType
---@field BufferPtr UnityEngine.Rendering.BuiltinRenderTextureType
---@field RenderTexture UnityEngine.Rendering.BuiltinRenderTextureType
---@field BindableTexture UnityEngine.Rendering.BuiltinRenderTextureType
---@field None UnityEngine.Rendering.BuiltinRenderTextureType
---@field CurrentActive UnityEngine.Rendering.BuiltinRenderTextureType
---@field CameraTarget UnityEngine.Rendering.BuiltinRenderTextureType
---@field Depth UnityEngine.Rendering.BuiltinRenderTextureType
---@field DepthNormals UnityEngine.Rendering.BuiltinRenderTextureType
---@field ResolvedDepth UnityEngine.Rendering.BuiltinRenderTextureType
---@field PrepassNormalsSpec UnityEngine.Rendering.BuiltinRenderTextureType
---@field PrepassLight UnityEngine.Rendering.BuiltinRenderTextureType
---@field PrepassLightSpec UnityEngine.Rendering.BuiltinRenderTextureType
---@field GBuffer0 UnityEngine.Rendering.BuiltinRenderTextureType
---@field GBuffer1 UnityEngine.Rendering.BuiltinRenderTextureType
---@field GBuffer2 UnityEngine.Rendering.BuiltinRenderTextureType
---@field GBuffer3 UnityEngine.Rendering.BuiltinRenderTextureType
---@field Reflections UnityEngine.Rendering.BuiltinRenderTextureType
---@field MotionVectors UnityEngine.Rendering.BuiltinRenderTextureType
---@field GBuffer4 UnityEngine.Rendering.BuiltinRenderTextureType
---@field GBuffer5 UnityEngine.Rendering.BuiltinRenderTextureType
---@field GBuffer6 UnityEngine.Rendering.BuiltinRenderTextureType
---@field GBuffer7 UnityEngine.Rendering.BuiltinRenderTextureType
local m = {}
UnityEngine = {}
UnityEngine.Rendering = {}
UnityEngine.Rendering.BuiltinRenderTextureType = m
return m