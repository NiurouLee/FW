---@class UnityEngine.AI.NavMeshObstacleShape : System.Enum
---@field value__ int
---@field Capsule UnityEngine.AI.NavMeshObstacleShape
---@field Box UnityEngine.AI.NavMeshObstacleShape
local m = {}
UnityEngine = {}
UnityEngine.AI = {}
UnityEngine.AI.NavMeshObstacleShape = m
return m