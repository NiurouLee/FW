---@class BlurColorLightLoader : UnityEngine.MonoBehaviour
---@field MainTexture string
---@field targetImage UnityEngine.UI.RawImage
local m = {}
---@param _mainTex string
function m:Load(_mainTex) end
BlurColorLightLoader = m
return m