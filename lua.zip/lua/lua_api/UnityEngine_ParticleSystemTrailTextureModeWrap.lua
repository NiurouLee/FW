---@class UnityEngine.ParticleSystemTrailTextureMode : System.Enum
---@field value__ int
---@field Stretch UnityEngine.ParticleSystemTrailTextureMode
---@field Tile UnityEngine.ParticleSystemTrailTextureMode
---@field DistributePerSegment UnityEngine.ParticleSystemTrailTextureMode
---@field RepeatPerSegment UnityEngine.ParticleSystemTrailTextureMode
local m = {}
UnityEngine = {}
UnityEngine.ParticleSystemTrailTextureMode = m
return m