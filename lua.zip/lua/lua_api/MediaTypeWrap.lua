---@class MediaType : System.Enum
---@field value__ int
---@field PICTURES MediaType
---@field MOVIES MediaType
---@field MUSIC MediaType
local m = {}
MediaType = m
return m