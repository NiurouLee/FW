---@class UISelectItem.State : System.Enum
---@field value__ int
---@field normal UISelectItem.State
---@field press UISelectItem.State
---@field selected UISelectItem.State
---@field disable UISelectItem.State
local m = {}
UISelectItem = {}
UISelectItem.State = m
return m