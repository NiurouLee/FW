---@class UnityEngine.Rendering.DefaultReflectionMode : System.Enum
---@field value__ int
---@field Skybox UnityEngine.Rendering.DefaultReflectionMode
---@field Custom UnityEngine.Rendering.DefaultReflectionMode
local m = {}
UnityEngine = {}
UnityEngine.Rendering = {}
UnityEngine.Rendering.DefaultReflectionMode = m
return m