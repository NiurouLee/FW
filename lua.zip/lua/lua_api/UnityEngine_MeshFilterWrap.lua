---@class UnityEngine.MeshFilter : UnityEngine.Component
---@field sharedMesh UnityEngine.Mesh
---@field mesh UnityEngine.Mesh
local m = {}
UnityEngine = {}
UnityEngine.MeshFilter = m
return m