---@class UnityEngine.VerticalWrapMode : System.Enum
---@field value__ int
---@field Truncate UnityEngine.VerticalWrapMode
---@field Overflow UnityEngine.VerticalWrapMode
local m = {}
UnityEngine = {}
UnityEngine.VerticalWrapMode = m
return m