---@class BaseUtil.CSvrPushEvent : BaseUtil.CPushEvent
---@field Reliable bool
local m = {}
BaseUtil = {}
BaseUtil.CSvrPushEvent = m
return m