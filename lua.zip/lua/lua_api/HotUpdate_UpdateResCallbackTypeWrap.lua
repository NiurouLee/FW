---@class HotUpdate.UpdateResCallbackType : System.Enum
---@field value__ int
---@field DownloadError HotUpdate.UpdateResCallbackType
---@field Downloading HotUpdate.UpdateResCallbackType
---@field WaitForFirstApp HotUpdate.UpdateResCallbackType
---@field Finish HotUpdate.UpdateResCallbackType
local m = {}
HotUpdate = {}
HotUpdate.UpdateResCallbackType = m
return m