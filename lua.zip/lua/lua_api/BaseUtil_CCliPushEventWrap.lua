---@class BaseUtil.CCliPushEvent : BaseUtil.CPushEvent
---@field Reliable bool
local m = {}
BaseUtil = {}
BaseUtil.CCliPushEvent = m
return m