---@class H3DGCloudLuaHelper.H3DPayGetInfoCallback : object
local m = {}
H3DGCloudLuaHelper = {}
H3DGCloudLuaHelper.H3DPayGetInfoCallback = m
return m