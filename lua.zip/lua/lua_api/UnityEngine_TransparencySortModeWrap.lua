---@class UnityEngine.TransparencySortMode : System.Enum
---@field value__ int
---@field Default UnityEngine.TransparencySortMode
---@field Perspective UnityEngine.TransparencySortMode
---@field Orthographic UnityEngine.TransparencySortMode
---@field CustomAxis UnityEngine.TransparencySortMode
local m = {}
UnityEngine = {}
UnityEngine.TransparencySortMode = m
return m