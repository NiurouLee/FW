---@class AnimationCurveAsset : UnityEngine.ScriptableObject
---@field animCurve UnityEngine.AnimationCurve
local m = {}
AnimationCurveAsset = m
return m