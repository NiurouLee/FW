---@class Cinemachine.CinemachineBlendDefinition.Style : System.Enum
---@field value__ int
---@field Cut Cinemachine.CinemachineBlendDefinition.Style
---@field EaseInOut Cinemachine.CinemachineBlendDefinition.Style
---@field EaseIn Cinemachine.CinemachineBlendDefinition.Style
---@field EaseOut Cinemachine.CinemachineBlendDefinition.Style
---@field HardIn Cinemachine.CinemachineBlendDefinition.Style
---@field HardOut Cinemachine.CinemachineBlendDefinition.Style
---@field Linear Cinemachine.CinemachineBlendDefinition.Style
---@field Custom Cinemachine.CinemachineBlendDefinition.Style
local m = {}
Cinemachine = {}
Cinemachine.CinemachineBlendDefinition = {}
Cinemachine.CinemachineBlendDefinition.Style = m
return m