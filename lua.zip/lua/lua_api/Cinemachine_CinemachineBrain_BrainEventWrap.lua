---@class Cinemachine.CinemachineBrain.BrainEvent : UnityEngine.Events.UnityEvent
local m = {}
Cinemachine = {}
Cinemachine.CinemachineBrain = {}
Cinemachine.CinemachineBrain.BrainEvent = m
return m