---@class bulletin_zone_info : object
---@field id int
---@field zone_name string
---@field domain_name string
---@field port int
---@field status int
---@field type int
---@field is_skip bool
local m = {}
bulletin_zone_info = m
return m