---@class BaseUtil.NetworkProtocol : System.Enum
---@field value__ int
---@field TCP BaseUtil.NetworkProtocol
---@field KCP BaseUtil.NetworkProtocol
---@field WebSocket BaseUtil.NetworkProtocol
local m = {}
BaseUtil = {}
BaseUtil.NetworkProtocol = m
return m