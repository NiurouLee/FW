---@class UnityEngine.Rendering.BuiltinShaderMode : System.Enum
---@field value__ int
---@field Disabled UnityEngine.Rendering.BuiltinShaderMode
---@field UseBuiltin UnityEngine.Rendering.BuiltinShaderMode
---@field UseCustom UnityEngine.Rendering.BuiltinShaderMode
local m = {}
UnityEngine = {}
UnityEngine.Rendering = {}
UnityEngine.Rendering.BuiltinShaderMode = m
return m