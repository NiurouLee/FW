---@class UnityEngine.Rendering.BlendMode : System.Enum
---@field value__ int
---@field Zero UnityEngine.Rendering.BlendMode
---@field One UnityEngine.Rendering.BlendMode
---@field DstColor UnityEngine.Rendering.BlendMode
---@field SrcColor UnityEngine.Rendering.BlendMode
---@field OneMinusDstColor UnityEngine.Rendering.BlendMode
---@field SrcAlpha UnityEngine.Rendering.BlendMode
---@field OneMinusSrcColor UnityEngine.Rendering.BlendMode
---@field DstAlpha UnityEngine.Rendering.BlendMode
---@field OneMinusDstAlpha UnityEngine.Rendering.BlendMode
---@field SrcAlphaSaturate UnityEngine.Rendering.BlendMode
---@field OneMinusSrcAlpha UnityEngine.Rendering.BlendMode
local m = {}
UnityEngine = {}
UnityEngine.Rendering = {}
UnityEngine.Rendering.BlendMode = m
return m