---@class UIAudioPlayer : UnityEngine.MonoBehaviour
---@field soundResName string
local m = {}
function m:Play() end
UIAudioPlayer = m
return m