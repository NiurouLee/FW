---@class INTL.INTLWebViewOrientation : System.Enum
---@field value__ int
---@field Auto INTL.INTLWebViewOrientation
---@field Portrait INTL.INTLWebViewOrientation
---@field Landscape INTL.INTLWebViewOrientation
local m = {}
INTL = {}
INTL.INTLWebViewOrientation = m
return m