---@class UnityEngine.Rendering.GraphicsTier : System.Enum
---@field value__ int
---@field Tier1 UnityEngine.Rendering.GraphicsTier
---@field Tier2 UnityEngine.Rendering.GraphicsTier
---@field Tier3 UnityEngine.Rendering.GraphicsTier
local m = {}
UnityEngine = {}
UnityEngine.Rendering = {}
UnityEngine.Rendering.GraphicsTier = m
return m