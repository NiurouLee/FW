---@class TMPro.TMP_InputValidator : UnityEngine.ScriptableObject
local m = {}
---@param text string
---@param pos int
---@param ch char
---@return char
function m:Validate(text, pos, ch) end
TMPro = {}
TMPro.TMP_InputValidator = m
return m