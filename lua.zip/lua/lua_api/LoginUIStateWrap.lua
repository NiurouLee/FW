---@class LoginUIState : System.Enum
---@field value__ int
---@field Invalid LoginUIState
---@field Open LoginUIState
---@field Close LoginUIState
local m = {}
LoginUIState = m
return m