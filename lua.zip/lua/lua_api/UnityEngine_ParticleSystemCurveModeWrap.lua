---@class UnityEngine.ParticleSystemCurveMode : System.Enum
---@field value__ int
---@field Constant UnityEngine.ParticleSystemCurveMode
---@field Curve UnityEngine.ParticleSystemCurveMode
---@field TwoCurves UnityEngine.ParticleSystemCurveMode
---@field TwoConstants UnityEngine.ParticleSystemCurveMode
local m = {}
UnityEngine = {}
UnityEngine.ParticleSystemCurveMode = m
return m