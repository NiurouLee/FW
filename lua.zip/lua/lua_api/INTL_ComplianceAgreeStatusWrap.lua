---@class INTL.ComplianceAgreeStatus : System.Enum
---@field value__ int
---@field Deny INTL.ComplianceAgreeStatus
---@field UnKnown INTL.ComplianceAgreeStatus
---@field Agree INTL.ComplianceAgreeStatus
local m = {}
INTL = {}
INTL.ComplianceAgreeStatus = m
return m