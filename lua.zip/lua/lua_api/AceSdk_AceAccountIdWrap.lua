---@class AceSdk.AceAccountId
---@field account_ string
---@field account_type_ ushort
local m = {}
AceSdk = {}
AceSdk.AceAccountId = m
return m