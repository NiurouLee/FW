---@class INTL.LevelInfinite.LIBaseEventResult : object
---@field lIEventType INTL.LevelInfinite.LIEventType
---@field extraJson string
local m = {}
INTL = {}
INTL.LevelInfinite = {}
INTL.LevelInfinite.LIBaseEventResult = m
return m