---@class INTL.ComplianceAgeStatus : System.Enum
---@field value__ int
---@field BelowGrade INTL.ComplianceAgeStatus
---@field Minor INTL.ComplianceAgeStatus
---@field UnKnown INTL.ComplianceAgeStatus
---@field Adult INTL.ComplianceAgeStatus
local m = {}
INTL = {}
INTL.ComplianceAgeStatus = m
return m