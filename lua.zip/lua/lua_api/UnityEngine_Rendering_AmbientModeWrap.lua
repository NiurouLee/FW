---@class UnityEngine.Rendering.AmbientMode : System.Enum
---@field value__ int
---@field Skybox UnityEngine.Rendering.AmbientMode
---@field Trilight UnityEngine.Rendering.AmbientMode
---@field Flat UnityEngine.Rendering.AmbientMode
---@field Custom UnityEngine.Rendering.AmbientMode
local m = {}
UnityEngine = {}
UnityEngine.Rendering = {}
UnityEngine.Rendering.AmbientMode = m
return m