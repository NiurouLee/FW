---@class H3DGCloudLuaHelper.H3DPayReprovideCallback : object
local m = {}
H3DGCloudLuaHelper = {}
H3DGCloudLuaHelper.H3DPayReprovideCallback = m
return m