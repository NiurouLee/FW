---@class UnityEngine.DepthTextureMode : System.Enum
---@field value__ int
---@field None UnityEngine.DepthTextureMode
---@field Depth UnityEngine.DepthTextureMode
---@field DepthNormals UnityEngine.DepthTextureMode
---@field MotionVectors UnityEngine.DepthTextureMode
local m = {}
UnityEngine = {}
UnityEngine.DepthTextureMode = m
return m