---@class UnityEngine.MeshRenderer : UnityEngine.Renderer
---@field additionalVertexStreams UnityEngine.Mesh
---@field subMeshStartIndex int
local m = {}
UnityEngine = {}
UnityEngine.MeshRenderer = m
return m