---@class HomeArea : UnityEngine.MonoBehaviour
---@field InterPoints table
---@field ExterPoints table
---@field RiverPoints table
---@field FishingPoints table
---@field ExterMat UnityEngine.Material
---@field InterMat UnityEngine.Material
local m = {}
HomeArea = m
return m