---@class Cinemachine.CinemachineCore.Stage : System.Enum
---@field value__ int
---@field Body Cinemachine.CinemachineCore.Stage
---@field Aim Cinemachine.CinemachineCore.Stage
---@field Noise Cinemachine.CinemachineCore.Stage
---@field Finalize Cinemachine.CinemachineCore.Stage
local m = {}
Cinemachine = {}
Cinemachine.CinemachineCore = {}
Cinemachine.CinemachineCore.Stage = m
return m