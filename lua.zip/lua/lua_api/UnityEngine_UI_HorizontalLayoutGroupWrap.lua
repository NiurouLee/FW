---@class UnityEngine.UI.HorizontalLayoutGroup : UnityEngine.UI.HorizontalOrVerticalLayoutGroup
local m = {}
function m:CalculateLayoutInputHorizontal() end
function m:CalculateLayoutInputVertical() end
function m:SetLayoutHorizontal() end
function m:SetLayoutVertical() end
UnityEngine = {}
UnityEngine.UI = {}
UnityEngine.UI.HorizontalLayoutGroup = m
return m