---@class UnityEngine.LOD
---@field screenRelativeTransitionHeight float
---@field fadeTransitionWidth float
---@field renderers table
local m = {}
UnityEngine = {}
UnityEngine.LOD = m
return m