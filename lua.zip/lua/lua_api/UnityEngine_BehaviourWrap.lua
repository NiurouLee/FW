---@class UnityEngine.Behaviour : UnityEngine.Component
---@field enabled bool
---@field isActiveAndEnabled bool
local m = {}
UnityEngine = {}
UnityEngine.Behaviour = m
return m