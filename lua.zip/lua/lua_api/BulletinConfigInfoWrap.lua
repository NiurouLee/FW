---@class BulletinConfigInfo : object
---@field name string
---@field ip string
---@field port ushort
local m = {}
BulletinConfigInfo = m
return m