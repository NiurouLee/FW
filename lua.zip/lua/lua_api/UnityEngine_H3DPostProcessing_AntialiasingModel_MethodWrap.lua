---@class UnityEngine.H3DPostProcessing.AntialiasingModel.Method : System.Enum
---@field value__ int
---@field Fxaa UnityEngine.H3DPostProcessing.AntialiasingModel.Method
---@field Taa UnityEngine.H3DPostProcessing.AntialiasingModel.Method
local m = {}
UnityEngine = {}
UnityEngine.H3DPostProcessing = {}
UnityEngine.H3DPostProcessing.AntialiasingModel = {}
UnityEngine.H3DPostProcessing.AntialiasingModel.Method = m
return m