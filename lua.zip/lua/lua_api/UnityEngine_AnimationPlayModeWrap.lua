---@class UnityEngine.AnimationPlayMode : System.Enum
---@field value__ int
---@field Stop UnityEngine.AnimationPlayMode
---@field Queue UnityEngine.AnimationPlayMode
---@field Mix UnityEngine.AnimationPlayMode
local m = {}
UnityEngine = {}
UnityEngine.AnimationPlayMode = m
return m