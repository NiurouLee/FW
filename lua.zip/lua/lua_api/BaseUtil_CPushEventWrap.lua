---@class BaseUtil.CPushEvent : BaseUtil.NetMessage
---@field Encrypt bool
---@field Reliable bool
local m = {}
BaseUtil = {}
BaseUtil.CPushEvent = m
return m