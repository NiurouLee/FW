---@class INTL.INTLNoticePicture : INTL.JsonSerializable
---@field Url string
---@field Hash string
---@field RedirectUrl string
---@field ExtraData string
local m = {}
INTL = {}
INTL.INTLNoticePicture = m
return m