---@class CacheHelper : object
local m = {}
---@return UnityEngine.Transform
function m.GetRoot() end
CacheHelper = m
return m