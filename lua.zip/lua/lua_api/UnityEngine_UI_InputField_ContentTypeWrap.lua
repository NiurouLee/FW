---@class UnityEngine.UI.InputField.ContentType : System.Enum
---@field value__ int
---@field Standard UnityEngine.UI.InputField.ContentType
---@field Autocorrected UnityEngine.UI.InputField.ContentType
---@field IntegerNumber UnityEngine.UI.InputField.ContentType
---@field DecimalNumber UnityEngine.UI.InputField.ContentType
---@field Alphanumeric UnityEngine.UI.InputField.ContentType
---@field Name UnityEngine.UI.InputField.ContentType
---@field EmailAddress UnityEngine.UI.InputField.ContentType
---@field Password UnityEngine.UI.InputField.ContentType
---@field Pin UnityEngine.UI.InputField.ContentType
---@field Custom UnityEngine.UI.InputField.ContentType
local m = {}
UnityEngine = {}
UnityEngine.UI = {}
UnityEngine.UI.InputField = {}
UnityEngine.UI.InputField.ContentType = m
return m