---@class ArtFont : UnityEngine.MonoBehaviour
---@field UpColor UnityEngine.Color
---@field DownColor UnityEngine.Color
---@field Division float
---@field UpBorder float
---@field DownBorder float
local m = {}
function m:UpdateValue() end
ArtFont = m
return m