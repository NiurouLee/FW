---@class UnityEngine.LightType : System.Enum
---@field value__ int
---@field Spot UnityEngine.LightType
---@field Directional UnityEngine.LightType
---@field Point UnityEngine.LightType
---@field Area UnityEngine.LightType
---@field Rectangle UnityEngine.LightType
---@field Disc UnityEngine.LightType
local m = {}
UnityEngine = {}
UnityEngine.LightType = m
return m