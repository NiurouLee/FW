---@class UnityEngine.HideFlags : System.Enum
---@field value__ int
---@field None UnityEngine.HideFlags
---@field HideInHierarchy UnityEngine.HideFlags
---@field HideInInspector UnityEngine.HideFlags
---@field DontSaveInEditor UnityEngine.HideFlags
---@field NotEditable UnityEngine.HideFlags
---@field DontSaveInBuild UnityEngine.HideFlags
---@field DontUnloadUnusedAsset UnityEngine.HideFlags
---@field DontSave UnityEngine.HideFlags
---@field HideAndDontSave UnityEngine.HideFlags
local m = {}
UnityEngine = {}
UnityEngine.HideFlags = m
return m