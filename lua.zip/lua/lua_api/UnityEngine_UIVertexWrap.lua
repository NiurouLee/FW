---@class UnityEngine.UIVertex
---@field position UnityEngine.Vector3
---@field normal UnityEngine.Vector3
---@field tangent UnityEngine.Vector4
---@field color UnityEngine.Color32
---@field uv0 UnityEngine.Vector2
---@field uv1 UnityEngine.Vector2
---@field uv2 UnityEngine.Vector2
---@field uv3 UnityEngine.Vector2
---@field simpleVert UnityEngine.UIVertex
local m = {}
UnityEngine = {}
UnityEngine.UIVertex = m
return m