---@class AceSdk.ClientInitInfo
---@field first_process_pid int
---@field current_process_role_id int
---@field base_dat_path string
local m = {}
AceSdk = {}
AceSdk.ClientInitInfo = m
return m