---@class UnityEngine.GradientMode : System.Enum
---@field value__ int
---@field Blend UnityEngine.GradientMode
---@field Fixed UnityEngine.GradientMode
local m = {}
UnityEngine = {}
UnityEngine.GradientMode = m
return m