--region NetCallerBulletin
---@class NetCallerBulletin:NetCallerDefault
_class("NetCallerBulletin", NetCallerDefault)

NetCallerBulletin = NetCallerBulletin
