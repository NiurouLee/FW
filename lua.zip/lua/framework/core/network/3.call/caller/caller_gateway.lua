--region NetCallerGateway
---@class NetCallerGateway:NetCallerDefault
_class("NetCallerGateway", NetCallerDefault)

NetCallerGateway = NetCallerGateway
