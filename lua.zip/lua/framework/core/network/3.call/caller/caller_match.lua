--region NetCallerMatch
---@class NetCallerMatch:NetCaller
_class("NetCallerMatch", NetCaller)
NetCallerMatch = NetCallerMatch
