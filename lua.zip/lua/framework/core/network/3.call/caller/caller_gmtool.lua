--region NetCallerGMTool
---@class NetCallerGMTool:NetCallerDefault
_class("NetCallerGMTool", NetCallerDefault)

NetCallerGMTool = NetCallerGMTool
