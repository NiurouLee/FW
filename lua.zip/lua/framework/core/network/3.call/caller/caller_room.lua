--region NetCallerRoom
---@class NetCallerRoom:NetCaller
_class("NetCallerRoom", NetCaller)
NetCallerRoom = NetCallerRoom
