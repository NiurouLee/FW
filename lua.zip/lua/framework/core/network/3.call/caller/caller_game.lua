--region NetCallerGame
---@class NetCallerGame:NetCaller
_class("NetCallerGame", NetCaller)
NetCallerGame = NetCallerGame
