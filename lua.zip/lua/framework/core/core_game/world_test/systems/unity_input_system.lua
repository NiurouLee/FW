---@class UnityInputSystem:Object
_class( "UnityInputSystem", Object )

---@param world BaseWorld
function UnityInputSystem:Constructor(world)
    self.world = world
end

function UnityInputSystem:Execute()

end

