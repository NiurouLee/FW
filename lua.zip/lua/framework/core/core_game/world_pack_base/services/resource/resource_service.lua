--[[------------------------------------------------------------------------------------------
    ResourceService
]] --------------------------------------------------------------------------------------------

---@class ResourceService:Object
_class("ResourceService", Object)

function ResourceService:Constructor()
end

function ResourceService:Initialize()
end

function ResourceService:Destructor()
end

function ResourceService:DestroyView(view)
end
