
---@class UIComponentParamType
local UIComponentParamType = {
    KeepVoice = 1,
}

_enum("UIComponentParamType", UIComponentParamType)