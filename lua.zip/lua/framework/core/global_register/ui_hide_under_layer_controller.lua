require("switch")

_class("UIHideUnderLayerControllerVER120", Singleton)

UIHideUnderLayerControllerVER120 = UIHideUnderLayerControllerVER120

UIHideUnderLayerControllerVER120.uiMap = 
{
    UIActivityReview = true,
    UIBattle = true,
    UIBattleResultComplete = true,
    UICampaignShopConfirmDetailController = true,
    UICampaignShopConfirmNormalController = true,
    UICommonLoading = true,
    UIDiscovery = true,
    UIGetItemController = true,
    UIN1Controller = true,
    UIN1LineMission = true,
    UIN1LineMission_Review = true,
    UIN1TacticsMission = true,
    UIN2LineMissionController = true,
    UIQuestAwardsInfoController = true,
    UIReport = true,
    UIShare = true,
    UIShopConfirmDetailController = true,
    UIShopConfirmNormalController = true,
    UIShopController = true,
    UISideEnterCenterController = true,
    UITeamsGuide = true,
    UIMailController = true,
    UISetController = true,
    UIQuestController = true,
    UIPlayerInfoController = true,
    UIGuideFailedController = true,
    UIStageRecordController = true
}