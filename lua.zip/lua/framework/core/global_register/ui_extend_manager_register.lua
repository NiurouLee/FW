_staticClass("UIExtendManagerRegister")

---@param uiControllerMgr UIControllerManager
function UIExtendManagerRegister:RegisterUIExtendManagers(uiControllerMgr)
    --uiControllerMgr:AddExtendManager(UIToastManager)
end